package com.sosconnect.agrocheck

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val etDni = findViewById<EditText>(R.id.etDni)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        btnLogin.setOnClickListener {
            val dni = etDni.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (dni.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese DNI y contraseña", Toast.LENGTH_SHORT).show()
            } else {
                // Navigate to RegisterPestActivity
                val intent = Intent(this, RegisterPestActivity::class.java)
                intent.putExtra("USER_DNI", dni)
                startActivity(intent)
            }
        }
    }
}
