package com.sosconnect.agrocheck

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.location.Location
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class RegisterPestActivity : AppCompatActivity() {

    private lateinit var etPestName: EditText
    private lateinit var ivPestPhoto: ImageView
    private lateinit var tvLatitude: TextView
    private lateinit var tvLongitude: TextView

    private var photoBitmap: Bitmap? = null

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(this, "Permiso de cámara concedido. Abriendo cámara...", Toast.LENGTH_SHORT).show()
            openCamera()
        } else {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                Toast.makeText(
                    this,
                    "El permiso de cámara fue denegado permanentemente. Puede habilitarlo en los ajustes de la aplicación.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Se necesita el permiso de cámara para utilizar la función.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private val takePictureLauncher = registerForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            photoBitmap = bitmap
            ivPestPhoto.setImageBitmap(bitmap)
            Toast.makeText(this, "Fotografía capturada con éxito", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Captura de fotografía cancelada o fallida", Toast.LENGTH_SHORT).show()
        }
    }

    private val locationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] ?: false
        val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] ?: false

        if (fineGranted || coarseGranted) {
            Toast.makeText(this, "Permiso de ubicación concedido", Toast.LENGTH_SHORT).show()
            obtainLocationAndProceed()
        } else {
            val showRationaleFine = ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
            val showRationaleCoarse = ActivityCompat.shouldShowRequestPermissionRationale(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )

            if (!showRationaleFine && !showRationaleCoarse) {
                Toast.makeText(
                    this,
                    "El permiso de ubicación fue denegado permanentemente. Puede habilitarlo en los ajustes de la aplicación.",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                Toast.makeText(
                    this,
                    "Se necesita el permiso de ubicación para utilizar la función.",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_pest)

        etPestName = findViewById(R.id.etPestName)
        ivPestPhoto = findViewById(R.id.ivPestPhoto)
        val btnTakePhoto = findViewById<Button>(R.id.btnTakePhoto)
        tvLatitude = findViewById(R.id.tvLatitude)
        tvLongitude = findViewById(R.id.tvLongitude)
        val btnContinue = findViewById<Button>(R.id.btnContinue)

        btnTakePhoto.setOnClickListener {
            checkAndRequestCameraPermission()
        }

        btnContinue.setOnClickListener {
            val pestName = etPestName.text.toString().trim()
            if (pestName.isEmpty()) {
                Toast.makeText(this, "Por favor ingrese el nombre de la plaga", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (photoBitmap == null) {
                Toast.makeText(this, "Recomendación: es recomendable tomar una fotografía de la plaga antes de continuar.", Toast.LENGTH_LONG).show()
            }

            checkAndRequestLocationPermission()
        }
    }

    private fun checkAndRequestCameraPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                openCamera()
            }
            else -> {
                cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun openCamera() {
        try {
            takePictureLauncher.launch(null)
        } catch (e: Exception) {
            Toast.makeText(this, "Error al abrir la cámara: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkAndRequestLocationPermission() {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            obtainLocationAndProceed()
        } else {
            locationPermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
    }

    private fun obtainLocationAndProceed() {
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!isGpsEnabled && !isNetworkEnabled) {
            Toast.makeText(
                this,
                "El GPS está desactivado. Por favor actívelo en la configuración del dispositivo para continuar.",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        var location: Location? = null
        try {
            if (isGpsEnabled) {
                location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            }
            if (location == null && isNetworkEnabled) {
                location = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            }
        } catch (e: SecurityException) {
            Toast.makeText(this, "Error de seguridad al acceder a la ubicación: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
            return
        }

        if (location != null) {
            val lat = location.latitude
            val lon = location.longitude

            tvLatitude.text = "Latitud: $lat"
            tvLongitude.text = "Longitud: $lon"

            val pestName = etPestName.text.toString().trim()
            val intent = Intent(this, SummaryActivity::class.java).apply {
                putExtra("PEST_NAME", pestName)
                putExtra("LATITUDE", lat.toString())
                putExtra("LONGITUDE", lon.toString())
                if (photoBitmap != null) {
                    putExtra("PEST_PHOTO", photoBitmap)
                }
            }
            startActivity(intent)
        } else {
            Toast.makeText(
                this,
                "No se pudo obtener la ubicación actual. Asegúrese de que el GPS tenga señal o reintente nuevamente.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
