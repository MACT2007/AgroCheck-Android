package com.sosconnect.agrocheck

import android.graphics.Bitmap
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SummaryActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_summary)

        val tvSummaryPestName = findViewById<TextView>(R.id.tvSummaryPestName)
        val ivSummaryPhoto = findViewById<ImageView>(R.id.ivSummaryPhoto)
        val tvSummaryLocation = findViewById<TextView>(R.id.tvSummaryLocation)
        val btnConfirmSend = findViewById<Button>(R.id.btnConfirmSend)

        val pestName = intent.getStringExtra("PEST_NAME") ?: "Desconocida"
        val latitude = intent.getStringExtra("LATITUDE") ?: "Sin datos"
        val longitude = intent.getStringExtra("LONGITUDE") ?: "Sin datos"

        val photoBitmap = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("PEST_PHOTO", Bitmap::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra("PEST_PHOTO") as? Bitmap
        }

        tvSummaryPestName.text = "${getString(R.string.label_pest_summary)}$pestName"
        tvSummaryLocation.text = "${getString(R.string.label_location_summary)}\nLat: $latitude\nLon: $longitude"

        if (photoBitmap != null) {
            ivSummaryPhoto.setImageBitmap(photoBitmap)
        } else {
            Toast.makeText(this, "No se adjuntó ninguna fotografía", Toast.LENGTH_SHORT).show()
        }

        btnConfirmSend.setOnClickListener {
            Toast.makeText(this, R.string.alert_confirmed_message, Toast.LENGTH_LONG).show()
            finishAffinity() // Close all activities and return or reset
        }
    }
}
